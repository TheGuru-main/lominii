"""LOMINII shared platform services."""
