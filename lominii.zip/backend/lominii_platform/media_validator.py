# platform/media_validator.py

MB = 1024 * 1024

MEDIA_RULES = {

    # ==========================================================
    # SOCIAL COMMENTS
    # ==========================================================
    "social_comment": {

        "image": {
            "max_size": 5 * MB,
        },

        "gif": {
            "max_size": 10 * MB,
        },

        "voice": {
            "max_size": 5 * MB,
            "max_duration": 120,
        },

        "video": {
            "max_size": 2 * MB,
            "max_duration": 120,
        },

        "file": {
            "max_size": 5 * MB,
        },
    },

    # ==========================================================
    # SOCIAL POSTS
    # ==========================================================
    "social_post": {

        "image": {
            "max_size": 20 * MB,
        },

        "gif": {
            "max_size": 20 * MB,
        },

        "voice": {
            "max_size": 20 * MB,
            "max_duration": 600,
        },

        "video": {
            "max_size": 500 * MB,
            "max_duration": 1800,
        },

        "file": {
            "max_size": 50 * MB,
        },
    },

    # ==========================================================
    # SOCIAL STATUS
    # ==========================================================
    "social_status": {

        "image": {
            "max_size": 10 * MB,
        },

        "voice": {
            "max_size": 10 * MB,
            "max_duration": 120,
        },

        "video": {
            "max_size": 100 * MB,
            "max_duration": 120,
        },
    },

    # ==========================================================
    # MESSAGING
    # (Social, Communities, Organizations, Games, Marketplace)
    # ==========================================================
    "messaging": {

        "image": {
            "max_size": 10 * MB,
        },

        "gif": {
            "max_size": 10 * MB,
        },

        "voice": {
            "max_size": 10 * MB,
            "max_duration": 300,
        },

        "video": {
            "max_size": 100 * MB,
            "max_duration": 900,
        },

        "file": {
            "max_size": 20 * MB,
        },
    },

    # ==========================================================
    # EDUCATION
    # ==========================================================
    "education": {

        "image": {
            "max_size": 20 * MB,
        },

        "voice": {
            "max_size": 20 * MB,
            "max_duration": 3600,
        },

        "video": {
            "max_size": 1024 * MB,
            "max_duration": 7200,
        },

        "file": {
            "max_size": 1024 * MB,
        },
    },
}

from fastapi import HTTPException


def validate_profile(profile: str):
    if profile not in MEDIA_RULES:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown media profile: {profile}",
        )

def validate_media_type(
    profile: str,
    media_type: str,
):
    validate_profile(profile)

    if media_type not in MEDIA_RULES[profile]:
        raise HTTPException(
            status_code=400,
            detail=f"{media_type} is not allowed for {profile}.",
        )

def validate_media_size(
    profile: str,
    media_type: str,
    size: int,
):
    limit = MEDIA_RULES[profile][media_type]["max_size"]

    if size > limit:
        raise HTTPException(
            status_code=400,
            detail="Media file exceeds the allowed size.",
        )

def validate_media_duration(
    profile: str,
    media_type: str,
    duration: int | None,
):
    rules = MEDIA_RULES[profile][media_type]

    if "max_duration" not in rules:
        return

    if duration is None:
        raise HTTPException(
            status_code=400,
            detail="Media duration is required.",
        )

    if duration > rules["max_duration"]:
        raise HTTPException(
            status_code=400,
            detail="Media exceeds the allowed duration.",
        )

def validate_media(
    profile: str,
    media_type: str,
    size: int,
    duration: int | None = None,
    extension: str | None = None,
    mime_type: str | None = None,
):
    validate_media_type(profile, media_type)
    validate_media_size(profile, media_type, size)
    validate_media_duration(profile, media_type, duration)

    if extension:
        validate_extension(
            profile,
            media_type,
            extension,
        )

    if mime_type:
        validate_mime_type(
            profile,
            media_type,
            mime_type,
        )

    return True

def validate_extension(
    profile: str,
    media_type: str,
    extension: str,
):
    rules = MEDIA_RULES[profile][media_type]

    if "extensions" not in rules:
        return

    extension = extension.lower().lstrip(".")

    if extension not in rules["extensions"]:
        raise HTTPException(
            status_code=400,
            detail="File extension is not allowed.",
        )

def validate_mime_type(
    profile: str,
    media_type: str,
    mime_type: str,
):
    rules = MEDIA_RULES[profile][media_type]

    if "mime_types" not in rules:
        return

    if mime_type not in rules["mime_types"]:
        raise HTTPException(
            status_code=400,
            detail="Media type is not allowed.",
        )